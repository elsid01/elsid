package CoreJava.DAO;

import CoreJava.Models.Attending;
import CoreJava.Models.Course;
import CoreJava.Models.Student;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
/*This method reads the Attending.csv file
 * and returns the data as a list
 */
public class AttendingDAO {

	public List<Attending> getAttending(){
		//Create a list of Attending type
		List<Attending> attendingList = new ArrayList<Attending>();
		//Read the file
		try {
			File file = new File("C:\\Users\\perscholas_student\\Final Project.zip_expanded\\Final Project\\School Management System\\src\\attending.csv");
			Scanner type = new Scanner(file);
			//ArrayList<String[]> data = new ArrayList<String[]>();
			while(type.hasNext()) {
				Attending attending = new Attending();
				String[] readString = type.nextLine().split(",");

				attending.setCourseID(Integer.parseInt(readString[0]));
				attending.setStudentEmail(readString[1]);
				attendingList.add(attending);
			}
			//close scanner
			type.close();
		} catch (FileNotFoundException e) {
			System.out.println("File not found!!?!");
			e.printStackTrace();
		}
		return attendingList;

	}
	/*This method takes a Student's email and a CourseID
	 * It checks if a Student with that Email is currently
	 * attending a course with that ID
	 */
	public void registerStudentToCourse(List<Attending> attending, String studentEmail, int courseID) throws IOException{
		//Enhanced for loop through the list
		for(Attending attendingStudent : attending) {
			if(attendingStudent.getStudentEmail().equals(studentEmail) && attendingStudent.getCourseID() == courseID) {
				return ;
			}
		}
		Attending attendingStudent = new Attending();
		attendingStudent.setCourseID(courseID);
		attendingStudent.setStudentEmail(studentEmail);
		attending.add(attendingStudent);
		saveAttending(attending);

	}
	/*This method takes a student's Email as a parameter
	 * and would search the AttendingList for all the courses 
	 * a student is registered to base on the id
	 */
	public List<Course> getStudentCourses(List<Course> courseList, List<Attending> attending, String studentEmail){
		List<Course> newCourseList = new ArrayList<>();
		for(Attending attendingCourse: attending ) {
			if( attendingCourse.getStudentEmail().equals(studentEmail)) {
				for(Course courseAttended: courseList) {
					if( courseAttended.getID()==attendingCourse.getCourseID()) {
						newCourseList.add(courseAttended);
					}		
				}
			}
		}
		return newCourseList;
	}
	/*This method overwrites the original Attending.csv 
	 *file with the new data 
	 */
	public void saveAttending(List<Attending> attending) throws IOException{


		File file = new File("C:\\Users\\perscholas_student\\Final Project.zip_expanded\\Final Project\\School Management System\\src\\attending.csv");
		FileWriter writer = new FileWriter(file,false);

		for(Attending attendingStudent: attending) {
			writer.write(String.format("%d,%s\n",attendingStudent.getCourseID(), attendingStudent.getStudentEmail()));
		}

		writer.close();


	}

}
