package CoreJava.DAO;

import CoreJava.Models.Course;
import CoreJava.Models.Student;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
/*This method takes no parameter and 
 * return every Course in the table 
 */
public class CourseDAO {
	public List<Course> getAllCourses(){
		List<Course> courseList = new ArrayList<Course>();

		try {
			File file = new File("C:\\Users\\perscholas_student\\Final Project.zip_expanded\\Final Project\\School Management System\\src\\courses.csv");
			Scanner type = new Scanner(file);
			//ArrayList<String[]> data = new ArrayList<String[]>();
			while(type.hasNext()) {
				Course course = new Course();
				String[] readString = type.nextLine().split(",");

				course.setID(Integer.parseInt(readString[0]));
				course.setName(readString[1]);
				course.setInstructor(readString[2]);
				courseList.add(course);
			}
			//close scanner
			type.close();
		} catch (FileNotFoundException e) {
			System.out.println("File not found!!?!");
			e.printStackTrace();
		}
		return courseList;
	}
}
