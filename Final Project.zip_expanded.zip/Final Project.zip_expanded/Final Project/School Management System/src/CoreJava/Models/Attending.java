package CoreJava.Models;

public class Attending {
	//class variables
	private int courseID;
	private String  studentEmail;
	
	//constructor with no parameter
	public Attending() {
		
	}
	//constructor with parameter
	public Attending(int ci, String em ) {
		this.courseID=ci;
		this.studentEmail=em;

	}
	//Getters and Setters
	public void setCourseID(int courseID){
		this.courseID=courseID;
	}

	public int getCourseID(){
		return courseID;
	}

	public void setStudentEmail(String studentEmail){
		this.studentEmail=studentEmail;
	}

	public String getStudentEmail(){
		return studentEmail;
	}
}
