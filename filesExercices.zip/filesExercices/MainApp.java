package filesExercices;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

import javax.print.DocFlavor.INPUT_STREAM;

import java.io.File;
import java.io.FileNotFoundException;
import java.security.KeyStore.TrustedCertificateEntry;
import java.util.Scanner;

public class MainApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String pathname="C:/Users/perscholas_student/Desktop/HelloFile.rtf";

		File file = new File(pathname);{

			try(Scanner scanner= new Scanner(file)){
				ArrayList<String> words = new ArrayList<String>();
				while(scanner.hasNext()) {
					words.add(scanner.nextLine());
				}
				for(int i=words.size()-1; i>=0;i--) {
					System.out.println(words.get(i));

			}
		}catch(FileNotFoundException e) {
			System.out.println(" No file found: " + pathname);


		}
	}


}

}

//21 minutes to complete