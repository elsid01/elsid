package filesExercices;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class ReadingMultipleFiles {

	public static void main(String[] args) {
		String pathName1="C:/Users/perscholas_student/Desktop/courseCode.txt";
		String pathName2="C:/Users/perscholas_student/Desktop/courseName.txt";
		String [] pathName = {pathName1,pathName2};
		File file1 = new File(pathName[0]);
		File file2 = new File(pathName[1]);
		
		try(Scanner sc1= new Scanner(file1); Scanner sc2=new Scanner(file2)) {
			while (sc1.hasNext() && sc2.hasNext()) {
				System.out.println(sc1.nextLine()+ " " + sc2.nextLine());
				
			}
		} catch (FileNotFoundException e) {
			
			System.out.println("File not found ");
		}

	}

}
// 30 minutes to complete