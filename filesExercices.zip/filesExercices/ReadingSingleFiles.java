package filesExercices;

import java.io.File;
import java.io.FileNotFoundException;
import java.security.KeyStore.TrustedCertificateEntry;
import java.util.Scanner;

public class ReadingSingleFiles {
	String pathname="C:\\Users\\perscholas_student\\Desktop\\HelloFile";
   
	File file = new File(pathname);{
	
	 try(Scanner scanner= new Scanner(file)){
	
	while(scanner.hasNext()) {
		System.out.println(scanner.nextLine()+ " ");
		
	}
	 }catch(FileNotFoundException e) {
		System.out.println(" No file found: " + pathname);
	
  
}
	 }
}
