package filesExercices;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class StoringStudent {

	public static void main(String[] args) throws IOException {
		
		String location1="C:\\Users\\perscholas_student\\Desktop\\Name.txt";
		String location2="C:\\Users\\perscholas_student\\Desktop\\Grade.txt";
		String location3="C:\\Users\\perscholas_student\\Desktop\\gpa.txt";
		
		File file1 = new File(location1);
		File file2 = new File(location2);
		File file3 = new File(location3);
		try(FileWriter writer1= new FileWriter(file1 ); 
				FileWriter writer2= new FileWriter(file2);
				FileWriter writer3= new FileWriter(file3)){
			Student student = new Student("Ely","12", "3.5");
			Student student2 = new Student("Moussa", "6","2.7" );

			writer1.write(student.getName()+"\n");
			writer2.write(student.getGrade()+"\n");
			writer3.write( student.getGpa()+"\n");
			
			writer1.write(student2.getName() + "\n");
			writer2.write(student2.getGrade()+ "\n");
			writer3.write( student2.getGpa() + "\n");
			
		System.out.println(student.getInfo());
		System.out.println(student2.getInfo());
			
		}catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		

	}

}
