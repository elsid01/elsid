package filesExercices;

public class Student {
  String name;
  String grade;
  String gpa;
 
 public Student() {
	
	this.name="";
	this.grade="" ;
	this.gpa="";
}

public Student(String name, String grade, String gpa) {
	 this.name=name;
	 this.grade= grade;
	 this.gpa=gpa;
 }
 
 public String getInfo() {
	 return "My name is " + this.name + " , I'M in " + this.grade + " grade"+ " ,and my"
	 		+ " gpa is " + this.gpa;
 }
 @Override
 public String toString() {
	 return this.name + "\n" + this.grade + "\n" + this.gpa;
 }
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getGrade() {
	return grade;
}
public void setGrade(String grade) {
	this.grade = grade;
}
public String getGpa() {
	return gpa;
}
public void setGpa(String gpa) {
	this.gpa = gpa;
}

	 
 

}
