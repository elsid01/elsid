package filesExercices;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class StudentRevisited1 {

	public static void main(String[] args) {
		String location1 ="C:\\Users\\perscholas_student\\Desktop\\names.txt";
		String location2 ="C:\\Users\\perscholas_student\\Desktop\\grades.txt";
		String location3 ="C:\\Users\\perscholas_student\\Desktop\\gpas.txt";
		
		File file1 = new File(location1);
		File file2 = new File(location2);
		File file3 = new File(location3);
		
//		Student[] container1= {};
//		String[] container2 ;
//		String[] container3 ;
		
		
		
		{
		
		try(Scanner sc1= new Scanner(file1); Scanner sc2=new Scanner(file2); Scanner sc3=new Scanner(file3)) {
//		String[] container1 ;
//          String[] container2 ;
//          String[] container3 ;
		
			ArrayList<Student> students = new ArrayList<Student>();
			
			while (sc1.hasNext() && sc2.hasNext()&& sc3.hasNext()) {
				
			 String[] container1= {sc1.nextLine()};
			 String [] container2= {sc2.nextLine()} ;
			 String [] container3= {sc3.nextLine()} ;
				
			//System.out.println(sc1.nextLine()+ " " + sc2.nextLine() + " " + sc3.nextLine());	
			}
			
		} catch (FileNotFoundException e) {
			
			System.out.println("File not found ");
		}
		

	}

	}

}
