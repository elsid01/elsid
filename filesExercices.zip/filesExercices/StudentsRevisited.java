package filesExercices;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class StudentsRevisited {
	
	String location1 ="C:\\Users\\perscholas_student\\Desktop\\names.txt";
	String location2 ="C:\\Users\\perscholas_student\\Desktop\\grades.txt";
	String location3 ="C:\\Users\\perscholas_student\\Desktop\\gpas.txt";
	
	File file1 = new File(location1);
	File file2 = new File(location2);
	File file3 = new File(location3);{
	
	try(Scanner sc1= new Scanner(file1); Scanner sc2=new Scanner(file2); Scanner sc3=new Scanner(file3)) {
		while (sc1.hasNext() && sc2.hasNext()&& sc3.hasNext()) {
			System.out.println(sc1.nextLine()+ " " + sc2.nextLine() + " " + sc3.nextLine());
			
		}
	} catch (FileNotFoundException e) {
		
		System.out.println("File not found ");
	}

}
}