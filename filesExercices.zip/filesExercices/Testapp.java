package filesExercices;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class Testapp {

	public static void main(String[] args) {
		String location="C:\\Users\\perscholas_student\\Desktop\\Name.txt";
		File file = new File(location);
		FileWriter writer;
		try(FileWriter writer2= new FileWriter(file);) {
			
			writer2.write("Ely");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		;

	}

}
